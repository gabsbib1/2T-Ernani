
// OBJETIVO
/**
 * Criar variavei e usá-la para modificar a DOM
 */
const titulo = document.getElementById("titulo")
const paragrafo = document.getElementById("paragrafo")
//alert(tituloparagrafo)
