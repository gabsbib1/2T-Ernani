// ARRAY OU LISTA SEQUENCIADA DE VALORES
const prod1 = "Camisa"
const prod2 = "Bermuda"
const prod3 = "Calça"

const produtos = ["Camisa", "Bermuda", "Calça", "Sapato"]
//                  0         1         2         3 
const precos = [10.99, 20, 30, 40.99]
produtos[5] // undefined - indefinido 
produtos[2] // Camisa
// SAIDA DE DADOS (alert, console.log, innerHTML))
console.log(produtos[0])
console.log(produtos[1])
console.log(precos[2])
console.log(precos[3])
console.log(precos[5])