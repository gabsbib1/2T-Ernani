html {
  height: 100%;
  width: 100%;
  background-color: grey;
}

.box {
  display: flex;
  flex-direction: column;
  width: 150px;
  background-color: grey;
  overflow: hidden;
  align-items: center;
}

.box button {
  width: 100%;
  background-color: green;
  cursor: pointer;
  color: black;
  padding: 5px;
  border-radius: 5px;
}

.box button:hover {
  background-color: #26cf3a;
}
