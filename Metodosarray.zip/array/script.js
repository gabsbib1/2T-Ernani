// MÉTODOS DE ARRAY
const comidas = ['churrasco', 'pizza']
comidas[3] = 'sushi' // MANUAL
comidas.push('beringela') // EMPURRANDO UM VALOR PARA O FINAL DA LISTA
console.log(comidas)