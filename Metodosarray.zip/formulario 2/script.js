// SELECIONAR ELEMENTOS HTML
const color = document.querySelector('#color');
const range = document.querySelector('#range');
const linha = document.querySelector('.linha');
const box = document.querySelector('.box');
const valorCor = document.querySelector('.valor-cor');
//alert(color.value) // valo dentro do input color
range.value = 0;

range.addEventListener('input', function() {
  box.style.borderRadius = range.value + 'px';
})
color.addEventListener('input', function() {
  box.style.backgroundColor = color.value;
  valorCor.innerHTML = color.value;
  valorCor.style.color = "white"
})

// CTRL + S




// CRIAR EVENTOS DE MANIPULAÇÃO
