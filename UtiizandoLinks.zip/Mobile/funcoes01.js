/**
 *  FUNÇÕES: São blocos de código que podem ser reaproveitados
 * Funções podem ou não ter nomes
 * Podem ou não receber parâmetros
 */
// CRIAR OU DECLAR FUNÇÕES


function dizOla(nome) {
  // código
  console.log('Olá!' + nome)
}
// INVOCAR / CHAMAR FUNÇÕES 
dizOla('Fernandinha')
dizOla('Felipe')
dizOla('Pedrocas')

// ADIÇÃO
function somaDoisNumeros(x, y) {
  const soma = x + y
  console.log(soma)
}
somaDoisNumeros(5, 9)
somaDoisNumeros(1, 5)
// SUBTRAÇÃO  
 function somaDoisNumeros(x, y) {
   const subtracao = x - y
   console.log(subtracao)
 }
somaDoisNumeros(7, 4)
somaDoisNumeros(9, 3)
// MULTIPLICAÇÃO
function somaDoisNumerosx(x, y) {
  const multiplicacao = x * y
  console.log(multiplicacao)
}
somaDoisNumeros(6, 7)
somaDoisNumeros(3, 2)
// DIVISÃO
function somaDoisNumeros(x, y) {
  const divisao = x / y
  console.log(divisao)
}
somaDoisNumeros(8, 5)
somaDoisNumeros(4, 6)