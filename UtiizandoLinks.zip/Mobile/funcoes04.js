// FUNÇÕES COM RETORNO
// SÃO FUNÇÕES QUE PERMITEM RETER O VALOR
// PROCESADO
// PARA UO POSTERIOR

const nome = 'Felipe'

function retornaDados() {
  //código com retorno
  return nome.toUpperCase()
  console.log('testando...') //INALCANÇÁVEL
  // A PARTIR DESSA LINHA NÃO EXECUTA MAIS NADA...
}
const dados = retornaDados()
alert(dados)
console.log(dados)

/**
 * CRIE UMA FUNÇÃO QUE RECEBA (nome, idade, cpf)
 * RETORNE OS DADOS FORMATADOS COM UMA MENSAGEM COM TODOS OS DADOS
 * ARMAZENE EM UMA VARIÁVEL E IMPRIMA COM CONSOLE.LOG()
 */
