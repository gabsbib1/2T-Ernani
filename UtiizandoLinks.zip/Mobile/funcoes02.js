// DECLARAÇÃO OU CRIAÇÃO
    // function soma(n1, n2){
    //   if (typeof n1 === 'number' && typeof n2 === 'number'){
    //     const res = n1 + n2
    //      alert('o resultado foi: ' + res')
    //   }else{
    //     alert('Por favor insira um numero valido')
    //   }
    // }
    //  soma('melancia', 5)   
    //  soma(5, 5)
    //  soma(-5, 4)

function dados(nome, sobrenome){
    if(typeof nome === 'string' && typeof sobrenome === 'string'){
        alert('Olá ' + nome +" "+ sobrenome + "!")
    }else{
        alert('Por favor insira um nome valido')}
}
dados('Fernandinha', 'Souza')
dados(12, 'Felipe')
dados(12, 67)

function dados(nome, altura){
    if(typeof nome === 'string' && typeof altura === 'number'){
        alert('Olá' + nome + 'sua altura é:' + altura + "!")
}else{alert('Por favor insira um texto valido')}
}
dados( 'Fernandinha', 1,57)
dados(12, 'Felipe')
dados(12, 67)