// CRIE  UMA FUNÇÃO QUE:
/**
 * RECEBA UM NÚMERO COMO PARÂMETRO E CHEQUE SE (if):
 *      N % 2 === 0 ENTÃO IMPRIMA "O número " + N + "É PAR!"
 *      SENÃO (else), IMPRIMA "O número " + N + " É ÍMPAR!"
 */
function parOuImpar(x){
  if(typeof x === 'number'){
    if(x % 2 === 0){
      alert('Olá, o número ' + x + ' é par!')
    }else{
      alert('Olá, o número ' + x + ' é ímpar!')
    }
  }else{
    alert('Por favor insira um número válido')
  }
} 
parOuImpar(2)
parOuImpar(23)
parOuImpar("Morango")